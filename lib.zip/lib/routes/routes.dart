const String kHomeRoute = '/';
const String kLoginFormRoute = '/loginForm';
const String kRegisterFormRoute = '/registerForm';
const String kResetFormRoute = '/resetForm';
const String kInitRoute = kHomeRoute;
